    function generarColorAleatorio() { // Función para generar un color aleatorio en formato hexadecimal
        const letras = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
          color += letras[Math.floor(Math.random() * 16)];
        }
        return color;
      }
  
      const boton = document.getElementById('change-color');  // Obtener referencias al botón y al cuadrado
      const cambiar = document.getElementById('cambiar');
  
      // Añadir un evento de clic al botón
      boton.addEventListener('click', () => {
        const colorAleatorio = generarColorAleatorio();
        cambiar.style.backgroundColor = colorAleatorio; // Cambiar el color del cuadrado
        cambiar.textContent = colorAleatorio; 
        cambiar.style.color = obtenerColorContraste(colorAleatorio); // Cambiar el color del texto según el contraste
      });
  
      function obtenerColorContraste(hexColor) { // Función para obtener un color de contraste (blanco o negro)
        const r = parseInt(hexColor.substr(1, 2), 16); // Convertir el color hexadecimal a valores RGB
        const g = parseInt(hexColor.substr(3, 2), 16); //     ||     ||  ||      ||      ||   ||    ||
        const b = parseInt(hexColor.substr(5, 2), 16);//      ||     ||  ||      ||      ||   ||    ||
  
        const brillo = (r * 0.299 + g * 0.587 + b * 0.114); // Calcular el brillo según la fórmula de luminancia relativa
  
        return brillo > 186 ? '#000000' : '#FFFFFF'; // Retornar blanco o negro según el brillo
      }